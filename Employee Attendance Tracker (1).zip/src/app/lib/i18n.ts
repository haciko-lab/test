import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      // Navigation
      dashboard: 'Dashboard',
      attendance: 'Attendance',
      leaves: 'Leaves',
      employees: 'Employees',
      reports: 'Reports',
      settings: 'Settings',
      logout: 'Logout',
      
      // Common
      checkIn: 'Check In',
      checkOut: 'Check Out',
      approve: 'Approve',
      reject: 'Reject',
      cancel: 'Cancel',
      save: 'Save',
      edit: 'Edit',
      delete: 'Delete',
      export: 'Export to Excel',
      search: 'Search',
      filter: 'Filter',
      select: 'Select',
      selectLanguage: 'Select Language',
      
      // Time
      today: 'Today',
      thisWeek: 'This Week',
      thisMonth: 'This Month',
      hours: 'Hours',
      days: 'Days',
      
      // Roles
      employee: 'Employee',
      manager: 'Manager',
      admin: 'Administrator',
      
      // Leave Types
      annualLeave: 'Annual Leave',
      sickLeave: 'Sick Leave',
      maternityLeave: 'Maternity Leave',
      specialLeave: 'Special Leave',
    }
  },
  es: {
    translation: {
      dashboard: 'Tablero',
      attendance: 'Asistencia',
      leaves: 'Permisos',
      employees: 'Empleados',
      reports: 'Informes',
      settings: 'Configuración',
      logout: 'Cerrar sesión',
      
      checkIn: 'Entrada',
      checkOut: 'Salida',
      approve: 'Aprobar',
      reject: 'Rechazar',
      cancel: 'Cancelar',
      save: 'Guardar',
      edit: 'Editar',
      delete: 'Eliminar',
      export: 'Exportar a Excel',
      search: 'Buscar',
      filter: 'Filtrar',
      select: 'Seleccionar',
      selectLanguage: 'Seleccionar idioma',
      
      today: 'Hoy',
      thisWeek: 'Esta semana',
      thisMonth: 'Este mes',
      hours: 'Horas',
      days: 'Días',
      
      employee: 'Empleado',
      manager: 'Gerente',
      admin: 'Administrador',
      
      annualLeave: 'Vacaciones',
      sickLeave: 'Permiso por enfermedad',
      maternityLeave: 'Permiso de maternidad',
      specialLeave: 'Permiso especial',
    }
  },
  fr: {
    translation: {
      dashboard: 'Tableau de bord',
      attendance: 'Présence',
      leaves: 'Congés',
      employees: 'Employés',
      reports: 'Rapports',
      settings: 'Paramètres',
      logout: 'Déconnexion',
      
      checkIn: 'Arrivée',
      checkOut: 'Départ',
      approve: 'Approuver',
      reject: 'Rejeter',
      cancel: 'Annuler',
      save: 'Enregistrer',
      edit: 'Modifier',
      delete: 'Supprimer',
      export: 'Exporter vers Excel',
      search: 'Rechercher',
      filter: 'Filtrer',
      select: 'Sélectionner',
      selectLanguage: 'Sélectionner la langue',
      
      today: "Aujourd'hui",
      thisWeek: 'Cette semaine',
      thisMonth: 'Ce mois',
      hours: 'Heures',
      days: 'Jours',
      
      employee: 'Employé',
      manager: 'Gestionnaire',
      admin: 'Administrateur',
      
      annualLeave: 'Congés annuels',
      sickLeave: 'Congé maladie',
      maternityLeave: 'Congé de maternité',
      specialLeave: 'Congé spécial',
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
