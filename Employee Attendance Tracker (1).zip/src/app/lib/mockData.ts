import { User, AttendanceRecord, LeaveRecord, LeaveBalance } from '../types';

export function generateMockData() {
  const users: User[] = [
    {
      id: '1',
      fullName: 'John Smith',
      dateOfBirth: '1990-05-15',
      employmentStartDate: '2020-01-10',
      role: 'employee',
      department: 'Engineering',
      isTerminated: false,
    },
    {
      id: '2',
      fullName: 'Sarah Johnson',
      dateOfBirth: '1988-08-22',
      employmentStartDate: '2019-03-15',
      role: 'employee',
      department: 'Marketing',
      isTerminated: false,
    },
    {
      id: '3',
      fullName: 'Michael Chen',
      dateOfBirth: '1985-11-30',
      employmentStartDate: '2018-06-01',
      role: 'manager',
      department: 'Engineering',
      isTerminated: false,
    },
    {
      id: '4',
      fullName: 'Emily Davis',
      dateOfBirth: '1992-02-14',
      employmentStartDate: '2021-09-01',
      role: 'employee',
      department: 'Sales',
      isTerminated: false,
    },
    {
      id: '5',
      fullName: 'Admin User',
      dateOfBirth: '1980-01-01',
      employmentStartDate: '2015-01-01',
      role: 'admin',
      department: 'Management',
      isTerminated: false,
    },
  ];

  const attendanceRecords: AttendanceRecord[] = [];
  const leaveRecords: LeaveRecord[] = [];
  const leaveBalances: LeaveBalance[] = [];

  // Generate attendance records for past 30 days
  const today = new Date();
  users.forEach(user => {
    if (!user.isTerminated) {
      for (let i = 0; i < 30; i++) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        
        // Skip weekends
        if (date.getDay() === 0 || date.getDay() === 6) continue;

        const checkInHour = 8 + Math.floor(Math.random() * 2);
        const checkInMinute = Math.floor(Math.random() * 60);
        const workHours = 8 + Math.floor(Math.random() * 3);
        
        const checkInTime = `${String(checkInHour).padStart(2, '0')}:${String(checkInMinute).padStart(2, '0')}`;
        const checkOutHour = checkInHour + workHours;
        const checkOutTime = `${String(checkOutHour).padStart(2, '0')}:${String(checkInMinute).padStart(2, '0')}`;

        const totalHours = workHours;
        const overtimeHours = totalHours > 8 ? totalHours - 8 : 0;
        const underworkHours = totalHours < 8 ? 8 - totalHours : 0;

        attendanceRecords.push({
          id: `att-${user.id}-${i}`,
          userId: user.id,
          date: date.toISOString().split('T')[0],
          checkInTime,
          checkOutTime,
          checkInLocation: {
            lat: 40.7128 + Math.random() * 0.01,
            lng: -74.006 + Math.random() * 0.01,
            address: 'Office Building, Main St',
          },
          checkOutLocation: {
            lat: 40.7128 + Math.random() * 0.01,
            lng: -74.006 + Math.random() * 0.01,
            address: 'Office Building, Main St',
          },
          totalHours,
          overtimeHours,
          underworkHours,
          status: checkInHour > 9 ? 'late' : overtimeHours > 0 ? 'overtime' : 'present',
          isApproved: i > 3,
        });
      }

      // Generate leave records
      const employmentDate = new Date(user.employmentStartDate);
      const yearsEmployed = (today.getTime() - employmentDate.getTime()) / (1000 * 60 * 60 * 24 * 365);
      const annualLeaveTotal = Math.min(20, 15 + Math.floor(yearsEmployed));
      const usedLeaves = Math.floor(Math.random() * 10);

      leaveBalances.push({
        userId: user.id,
        annualLeaveTotal,
        annualLeaveUsed: usedLeaves,
        annualLeaveRemaining: annualLeaveTotal - usedLeaves,
        renewalDate: new Date(employmentDate.getFullYear() + Math.ceil(yearsEmployed), employmentDate.getMonth(), employmentDate.getDate()).toISOString().split('T')[0],
        sickLeaveUsed: Math.floor(Math.random() * 3),
        maternityLeaveUsed: user.fullName.includes('Sarah') ? 90 : 0,
        specialLeaveUsed: Math.floor(Math.random() * 2),
      });

      // Add some leave records
      for (let i = 0; i < 3; i++) {
        const leaveDate = new Date(today);
        leaveDate.setDate(leaveDate.getDate() - Math.floor(Math.random() * 90));
        
        leaveRecords.push({
          id: `leave-${user.id}-${i}`,
          userId: user.id,
          leaveType: ['annual', 'sick', 'special'][Math.floor(Math.random() * 3)] as any,
          startDate: leaveDate.toISOString().split('T')[0],
          endDate: new Date(leaveDate.getTime() + Math.floor(Math.random() * 5) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          days: 1 + Math.floor(Math.random() * 4),
          reason: 'Personal reasons',
          status: i === 0 ? 'pending' : Math.random() > 0.5 ? 'approved' : 'rejected',
        });
      }
    }
  });

  return {
    users,
    attendanceRecords,
    leaveRecords,
    leaveBalances,
  };
}
