export type Role = 'employee' | 'manager' | 'admin';

export type LeaveType = 'annual' | 'sick' | 'maternity' | 'special';

export type AttendanceStatus = 'present' | 'absent' | 'late' | 'overtime';

export interface User {
  id: string;
  fullName: string;
  dateOfBirth: string;
  employmentStartDate: string;
  role: Role;
  department: string;
  isTerminated: boolean;
  terminatedDate?: string;
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  date: string;
  checkInTime?: string;
  checkOutTime?: string;
  checkInLocation?: { lat: number; lng: number; address: string };
  checkOutLocation?: { lat: number; lng: number; address: string };
  totalHours?: number;
  overtimeHours?: number;
  underworkHours?: number;
  status: AttendanceStatus;
  isApproved: boolean;
  approvedBy?: string;
}

export interface LeaveRecord {
  id: string;
  userId: string;
  leaveType: LeaveType;
  startDate: string;
  endDate: string;
  days: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  approvedBy?: string;
}

export interface LeaveBalance {
  userId: string;
  annualLeaveTotal: number;
  annualLeaveUsed: number;
  annualLeaveRemaining: number;
  renewalDate: string;
  sickLeaveUsed: number;
  maternityLeaveUsed: number;
  specialLeaveUsed: number;
}

export interface AttendanceCorrectionRequest {
  id: string;
  recordId: string;
  userId: string;
  requestedCheckInTime: string;
  requestedCheckOutTime: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
}