import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Label } from '../ui/label';
import { User, Shield, Users as UsersIcon } from 'lucide-react';
import { User as UserType, Role } from '../../types';

interface LoginScreenProps {
  onLogin: (user: UserType, role: Role) => void;
  users: UserType[];
}

export function LoginScreen({ onLogin, users }: LoginScreenProps) {
  const { t } = useTranslation();
  const [selectedUserId, setSelectedUserId] = useState('');
  const [selectedRole, setSelectedRole] = useState<Role>('employee');

  const handleLogin = () => {
    const user = users.find(u => u.id === selectedUserId);
    if (user) {
      onLogin(user, selectedRole);
    }
  };

  const getRoleIcon = (role: Role) => {
    switch (role) {
      case 'employee':
        return <User className="h-4 w-4" />;
      case 'manager':
        return <UsersIcon className="h-4 w-4" />;
      case 'admin':
        return <Shield className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4">
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center space-y-2">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center mb-2">
            <UsersIcon className="h-8 w-8 text-white" />
          </div>
          <CardTitle className="text-2xl">Workforce Management</CardTitle>
          <CardDescription>
            Enterprise Attendance & HR System
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="user">Select User</Label>
            <Select value={selectedUserId} onValueChange={setSelectedUserId}>
              <SelectTrigger id="user">
                <SelectValue placeholder="Choose your profile..." />
              </SelectTrigger>
              <SelectContent>
                {users.filter(u => !u.isTerminated).map(user => (
                  <SelectItem key={user.id} value={user.id}>
                    <div className="flex items-center gap-2">
                      <span>{user.fullName}</span>
                      <span className="text-xs text-muted-foreground">({user.department})</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">{t('select')} Role</Label>
            <Select value={selectedRole} onValueChange={(v) => setSelectedRole(v as Role)}>
              <SelectTrigger id="role">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="employee">
                  <div className="flex items-center gap-2">
                    {getRoleIcon('employee')}
                    <span>{t('employee')}</span>
                  </div>
                </SelectItem>
                <SelectItem value="manager">
                  <div className="flex items-center gap-2">
                    {getRoleIcon('manager')}
                    <span>{t('manager')}</span>
                  </div>
                </SelectItem>
                <SelectItem value="admin">
                  <div className="flex items-center gap-2">
                    {getRoleIcon('admin')}
                    <span>{t('admin')}</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button 
            className="w-full h-12 text-base"
            onClick={handleLogin}
            disabled={!selectedUserId}
          >
            Sign In
          </Button>

          <p className="text-xs text-center text-muted-foreground">
            Demo Mode - All data is simulated
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
