import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { User, Shield, Users } from 'lucide-react';

interface LoginProps {
  onLogin: (userId: string, role: 'employee' | 'manager' | 'admin') => void;
}

export function Login({ onLogin }: LoginProps) {
  const [selectedUser, setSelectedUser] = useState<string>('');
  const [selectedRole, setSelectedRole] = useState<'employee' | 'manager' | 'admin'>('employee');

  const users = [
    { id: '1', name: 'John Smith', role: 'employee' },
    { id: '2', name: 'Sarah Johnson', role: 'employee' },
    { id: '3', name: 'Michael Chen', role: 'manager' },
    { id: '4', name: 'Admin User', role: 'admin' },
  ];

  const handleLogin = () => {
    if (selectedUser) {
      onLogin(selectedUser, selectedRole);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl text-center">Employee Attendance System</CardTitle>
          <CardDescription className="text-center">
            Select your profile to access the system
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="user">Select User</Label>
            <Select value={selectedUser} onValueChange={setSelectedUser}>
              <SelectTrigger id="user">
                <SelectValue placeholder="Choose a user..." />
              </SelectTrigger>
              <SelectContent>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.name} ({user.role})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">Login As</Label>
            <Select value={selectedRole} onValueChange={(value) => setSelectedRole(value as any)}>
              <SelectTrigger id="role">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="employee">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    <span>Employee</span>
                  </div>
                </SelectItem>
                <SelectItem value="manager">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    <span>Manager</span>
                  </div>
                </SelectItem>
                <SelectItem value="admin">
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4" />
                    <span>Administrator</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button className="w-full" onClick={handleLogin} disabled={!selectedUser}>
            Sign In
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
