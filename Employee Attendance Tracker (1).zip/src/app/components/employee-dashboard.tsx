import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { MapPin, Clock, Calendar, LogIn, LogOut, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

interface AttendanceRecord {
  id: string;
  employeeId: string;
  checkIn: Date;
  checkOut?: Date;
  checkInLocation: { lat: number; lng: number; address: string };
  checkOutLocation?: { lat: number; lng: number; address: string };
  status: 'checked-in' | 'checked-out' | 'pending-approval';
  hoursWorked?: number;
}

interface EmployeeDashboardProps {
  userId: string;
  userName: string;
  attendanceRecords: AttendanceRecord[];
  onCheckIn: (location: { lat: number; lng: number; address: string }) => void;
  onCheckOut: (location: { lat: number; lng: number; address: string }) => void;
}

export function EmployeeDashboard({
  userId,
  userName,
  attendanceRecords,
  onCheckIn,
  onCheckOut,
}: EmployeeDashboardProps) {
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number; address: string } | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  
  const todayRecords = attendanceRecords.filter((record) => {
    const today = new Date();
    return (
      record.checkIn.toDateString() === today.toDateString()
    );
  });

  const currentCheckIn = todayRecords.find((record) => !record.checkOut);
  const isCheckedIn = !!currentCheckIn;

  const weekRecords = attendanceRecords.filter((record) => {
    const today = new Date();
    const weekAgo = new Date(today);
    weekAgo.setDate(weekAgo.getDate() - 7);
    return record.checkIn >= weekAgo;
  });

  const totalHoursThisWeek = weekRecords.reduce((sum, record) => sum + (record.hoursWorked || 0), 0);

  const getCurrentLocation = () => {
    setIsLoadingLocation(true);
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const location = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            address: `${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`,
          };
          setCurrentLocation(location);
          setIsLoadingLocation(false);
          toast.success('Location captured successfully');
        },
        () => {
          // Fallback to mock location if GPS fails
          const mockLocation = {
            lat: 40.7128 + Math.random() * 0.01,
            lng: -74.006 + Math.random() * 0.01,
            address: 'Office Location (Mock)',
          };
          setCurrentLocation(mockLocation);
          setIsLoadingLocation(false);
          toast.info('Using mock location (GPS unavailable)');
        }
      );
    } else {
      const mockLocation = {
        lat: 40.7128,
        lng: -74.006,
        address: 'Office Location (Mock)',
      };
      setCurrentLocation(mockLocation);
      setIsLoadingLocation(false);
      toast.info('Using mock location');
    }
  };

  const handleCheckIn = () => {
    if (currentLocation) {
      onCheckIn(currentLocation);
      toast.success('Checked in successfully!');
    } else {
      toast.error('Please capture your location first');
    }
  };

  const handleCheckOut = () => {
    if (currentLocation) {
      onCheckOut(currentLocation);
      toast.success('Checked out successfully!');
    } else {
      toast.error('Please capture your location first');
    }
  };

  useEffect(() => {
    getCurrentLocation();
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl mb-1">Welcome back, {userName}</h2>
        <p className="text-muted-foreground">Manage your attendance and view your timesheet</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Status</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{isCheckedIn ? 'Checked In' : 'Checked Out'}</div>
            <p className="text-xs text-muted-foreground">
              {isCheckedIn && currentCheckIn
                ? `Since ${formatTime(currentCheckIn.checkIn)}`
                : 'Ready to check in'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Hours This Week</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{totalHoursThisWeek.toFixed(1)} hrs</div>
            <p className="text-xs text-muted-foreground">
              {weekRecords.length} days worked
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Leave Balance</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">15 days</div>
            <p className="text-xs text-muted-foreground">Annual leave remaining</p>
          </CardContent>
        </Card>
      </div>

      {/* Check In/Out Section */}
      <Card>
        <CardHeader>
          <CardTitle>Attendance Check</CardTitle>
          <CardDescription>Use GPS to check in or out from work</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-2 p-4 bg-muted rounded-lg">
            <MapPin className="h-5 w-5 text-muted-foreground mt-0.5" />
            <div className="flex-1">
              <p className="text-sm">Current Location</p>
              {currentLocation ? (
                <p className="text-xs text-muted-foreground">{currentLocation.address}</p>
              ) : (
                <p className="text-xs text-muted-foreground">Location not captured</p>
              )}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={getCurrentLocation}
              disabled={isLoadingLocation}
            >
              <RefreshCw className={`h-4 w-4 ${isLoadingLocation ? 'animate-spin' : ''}`} />
            </Button>
          </div>

          <div className="flex gap-3">
            <Button
              className="flex-1"
              onClick={handleCheckIn}
              disabled={isCheckedIn || !currentLocation}
            >
              <LogIn className="h-4 w-4 mr-2" />
              Check In
            </Button>
            <Button
              className="flex-1"
              variant="outline"
              onClick={handleCheckOut}
              disabled={!isCheckedIn || !currentLocation}
            >
              <LogOut className="h-4 w-4 mr-2" />
              Check Out
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Attendance */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Attendance</CardTitle>
          <CardDescription>Your attendance history for the past week</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {weekRecords.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                No attendance records this week
              </p>
            ) : (
              weekRecords.slice(0, 7).map((record) => (
                <div key={record.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <p className="text-sm">{formatDate(record.checkIn)}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatTime(record.checkIn)} -{' '}
                      {record.checkOut ? formatTime(record.checkOut) : 'In Progress'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm">
                      {record.hoursWorked ? `${record.hoursWorked.toFixed(1)} hrs` : '-'}
                    </p>
                    <Badge
                      variant={
                        record.status === 'checked-out'
                          ? 'default'
                          : record.status === 'checked-in'
                          ? 'secondary'
                          : 'outline'
                      }
                      className="text-xs"
                    >
                      {record.status === 'checked-in' ? 'Active' : record.status === 'checked-out' ? 'Completed' : 'Pending'}
                    </Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
