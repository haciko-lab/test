import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Users, Clock, Calendar, Shield } from 'lucide-react';
import { toast } from 'sonner';

interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  checkIn: Date;
  checkOut?: Date;
  checkInLocation: { lat: number; lng: number; address: string };
  checkOutLocation?: { lat: number; lng: number; address: string };
  status: 'checked-in' | 'checked-out' | 'pending-approval';
  hoursWorked?: number;
}

interface Employee {
  id: string;
  name: string;
  department: string;
  leaveBalance: number;
  totalHoursThisMonth: number;
  overtimeHours: number;
}

interface AdminDashboardProps {
  allAttendanceRecords: AttendanceRecord[];
  onManualCorrection: (recordId: string, newCheckIn: Date, newCheckOut: Date) => void;
}

const mockEmployees: Employee[] = [
  {
    id: '1',
    name: 'John Smith',
    department: 'Engineering',
    leaveBalance: 15,
    totalHoursThisMonth: 168,
    overtimeHours: 8,
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    department: 'Marketing',
    leaveBalance: 12,
    totalHoursThisMonth: 160,
    overtimeHours: 0,
  },
  {
    id: '3',
    name: 'Michael Chen',
    department: 'Sales',
    leaveBalance: 18,
    totalHoursThisMonth: 176,
    overtimeHours: 16,
  },
];

export function AdminDashboard({
  allAttendanceRecords,
  onManualCorrection,
}: AdminDashboardProps) {
  const [showCorrectionDialog, setShowCorrectionDialog] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<AttendanceRecord | null>(null);
  const [correctionCheckIn, setCorrectionCheckIn] = useState('');
  const [correctionCheckOut, setCorrectionCheckOut] = useState('');

  const totalEmployees = mockEmployees.length;
  const totalOvertimeHours = mockEmployees.reduce((sum, emp) => sum + emp.overtimeHours, 0);
  const avgLeaveBalance = mockEmployees.reduce((sum, emp) => sum + emp.leaveBalance, 0) / totalEmployees;

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const formatDateTime = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };

  const handleOpenCorrectionDialog = (record: AttendanceRecord) => {
    setSelectedRecord(record);
    setCorrectionCheckIn(formatDateTime(record.checkIn));
    setCorrectionCheckOut(record.checkOut ? formatDateTime(record.checkOut) : '');
    setShowCorrectionDialog(true);
  };

  const handleSaveCorrection = () => {
    if (selectedRecord && correctionCheckIn && correctionCheckOut) {
      const newCheckIn = new Date(correctionCheckIn);
      const newCheckOut = new Date(correctionCheckOut);
      
      if (newCheckOut <= newCheckIn) {
        toast.error('Check-out time must be after check-in time');
        return;
      }

      onManualCorrection(selectedRecord.id, newCheckIn, newCheckOut);
      toast.success('Attendance record corrected successfully');
      setShowCorrectionDialog(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl mb-1">Administrator Dashboard</h2>
        <p className="text-muted-foreground">System-wide attendance management and reporting</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Employees</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{totalEmployees}</div>
            <p className="text-xs text-muted-foreground">Active in system</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Records</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{allAttendanceRecords.length}</div>
            <p className="text-xs text-muted-foreground">All time</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Overtime Hours</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{totalOvertimeHours}</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Avg Leave Balance</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{avgLeaveBalance.toFixed(1)}</div>
            <p className="text-xs text-muted-foreground">Days per employee</p>
          </CardContent>
        </Card>
      </div>

      {/* Management Tabs */}
      <Tabs defaultValue="employees" className="space-y-4">
        <TabsList>
          <TabsTrigger value="employees">Employee Overview</TabsTrigger>
          <TabsTrigger value="attendance">Attendance Records</TabsTrigger>
          <TabsTrigger value="corrections">Manual Corrections</TabsTrigger>
        </TabsList>

        <TabsContent value="employees" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Employee Summary</CardTitle>
              <CardDescription>Overview of all employees and their attendance metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Hours (Month)</TableHead>
                    <TableHead>Overtime</TableHead>
                    <TableHead>Leave Balance</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockEmployees.map((employee) => (
                    <TableRow key={employee.id}>
                      <TableCell>{employee.name}</TableCell>
                      <TableCell>{employee.department}</TableCell>
                      <TableCell>{employee.totalHoursThisMonth} hrs</TableCell>
                      <TableCell>
                        {employee.overtimeHours > 0 ? (
                          <Badge variant="secondary">{employee.overtimeHours} hrs</Badge>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>{employee.leaveBalance} days</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attendance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Attendance Records</CardTitle>
              <CardDescription>Complete attendance history across all employees</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Check In</TableHead>
                    <TableHead>Check Out</TableHead>
                    <TableHead>Hours</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {allAttendanceRecords.slice(0, 20).map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>{record.employeeName}</TableCell>
                      <TableCell>{formatDate(record.checkIn)}</TableCell>
                      <TableCell>{formatTime(record.checkIn)}</TableCell>
                      <TableCell>
                        {record.checkOut ? formatTime(record.checkOut) : '-'}
                      </TableCell>
                      <TableCell>
                        {record.hoursWorked ? `${record.hoursWorked.toFixed(1)} hrs` : '-'}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            record.status === 'checked-in'
                              ? 'secondary'
                              : record.status === 'checked-out'
                              ? 'default'
                              : 'outline'
                          }
                        >
                          {record.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOpenCorrectionDialog(record)}
                        >
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="corrections" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Manual Corrections</CardTitle>
              <CardDescription>
                Correct attendance records with incorrect check-in/check-out times
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2 p-4 bg-muted rounded-lg">
                  <Shield className="h-5 w-5 text-muted-foreground" />
                  <div className="flex-1">
                    <p className="text-sm">Administrator Privilege</p>
                    <p className="text-xs text-muted-foreground">
                      You can manually edit any attendance record. All changes are logged.
                    </p>
                  </div>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Current Times</TableHead>
                      <TableHead>Hours</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {allAttendanceRecords.slice(0, 10).map((record) => (
                      <TableRow key={record.id}>
                        <TableCell>{record.employeeName}</TableCell>
                        <TableCell>{formatDate(record.checkIn)}</TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <div>In: {formatTime(record.checkIn)}</div>
                            <div>
                              Out: {record.checkOut ? formatTime(record.checkOut) : 'N/A'}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          {record.hoursWorked ? `${record.hoursWorked.toFixed(1)} hrs` : '-'}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleOpenCorrectionDialog(record)}
                          >
                            Correct
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Manual Correction Dialog */}
      <Dialog open={showCorrectionDialog} onOpenChange={setShowCorrectionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Manual Attendance Correction</DialogTitle>
            <DialogDescription>
              Update the check-in and check-out times for this record
            </DialogDescription>
          </DialogHeader>
          {selectedRecord && (
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Employee</p>
                <p className="text-sm">{selectedRecord.employeeName}</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="checkIn">Check In Time</Label>
                <Input
                  id="checkIn"
                  type="datetime-local"
                  value={correctionCheckIn}
                  onChange={(e) => setCorrectionCheckIn(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="checkOut">Check Out Time</Label>
                <Input
                  id="checkOut"
                  type="datetime-local"
                  value={correctionCheckOut}
                  onChange={(e) => setCorrectionCheckOut(e.target.value)}
                />
              </div>

              <div className="p-3 bg-muted rounded-lg">
                <p className="text-xs text-muted-foreground">
                  Note: Manual corrections are logged for audit purposes. Ensure you have
                  authorization to make these changes.
                </p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCorrectionDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveCorrection}>Save Correction</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
