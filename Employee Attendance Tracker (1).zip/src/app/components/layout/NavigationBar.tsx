import { useTranslation } from 'react-i18next';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { LogOut, Globe } from 'lucide-react';
import { User, Role } from '../../types';

interface NavigationBarProps {
  user: User;
  role: Role;
  onLogout: () => void;
  onLanguageChange: (lng: string) => void;
  currentLanguage: string;
}

export function NavigationBar({ user, role, onLogout, onLanguageChange, currentLanguage }: NavigationBarProps) {
  const { t } = useTranslation();

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center">
              <span className="text-white text-xl">👔</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-lg">Workforce Manager</h1>
              <p className="text-xs text-gray-500">{user.fullName} · {t(role)}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden md:flex items-center gap-2">
              <Globe className="h-4 w-4 text-gray-500" />
              <Select value={currentLanguage} onValueChange={onLanguageChange}>
                <SelectTrigger className="w-24 h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Español</SelectItem>
                  <SelectItem value="fr">Français</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button variant="outline" size="sm" onClick={onLogout} className="h-9">
              <LogOut className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">{t('logout')}</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
