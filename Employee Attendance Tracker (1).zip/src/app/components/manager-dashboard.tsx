import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Users, Clock, Check, X, MapPin } from 'lucide-react';
import { toast } from 'sonner';

interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  checkIn: Date;
  checkOut?: Date;
  checkInLocation: { lat: number; lng: number; address: string };
  checkOutLocation?: { lat: number; lng: number; address: string };
  status: 'checked-in' | 'checked-out' | 'pending-approval';
  hoursWorked?: number;
}

interface ManagerDashboardProps {
  allAttendanceRecords: AttendanceRecord[];
  onApprove: (recordId: string) => void;
  onReject: (recordId: string) => void;
}

export function ManagerDashboard({
  allAttendanceRecords,
  onApprove,
  onReject,
}: ManagerDashboardProps) {
  const [selectedRecord, setSelectedRecord] = useState<AttendanceRecord | null>(null);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);

  const pendingRecords = allAttendanceRecords.filter((r) => r.status === 'pending-approval');
  const approvedRecords = allAttendanceRecords.filter((r) => r.status === 'checked-out');

  const todayRecords = allAttendanceRecords.filter((record) => {
    const today = new Date();
    return record.checkIn.toDateString() === today.toDateString();
  });

  const activeEmployees = todayRecords.filter((r) => r.status === 'checked-in').length;
  const totalEmployees = new Set(allAttendanceRecords.map((r) => r.employeeId)).size;

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const handleViewDetails = (record: AttendanceRecord) => {
    setSelectedRecord(record);
    setShowDetailsDialog(true);
  };

  const handleApprove = (recordId: string) => {
    onApprove(recordId);
    toast.success('Attendance record approved');
    setShowDetailsDialog(false);
  };

  const handleReject = (recordId: string) => {
    onReject(recordId);
    toast.success('Attendance record rejected');
    setShowDetailsDialog(false);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl mb-1">Manager Dashboard</h2>
        <p className="text-muted-foreground">Review and approve team attendance</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Active Today</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{activeEmployees}</div>
            <p className="text-xs text-muted-foreground">
              of {totalEmployees} total employees
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Pending Approvals</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{pendingRecords.length}</div>
            <p className="text-xs text-muted-foreground">Records awaiting review</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Today's Check-ins</CardTitle>
            <Check className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{todayRecords.length}</div>
            <p className="text-xs text-muted-foreground">Total for today</p>
          </CardContent>
        </Card>
      </div>

      {/* Attendance Management Tabs */}
      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pending">
            Pending Approval ({pendingRecords.length})
          </TabsTrigger>
          <TabsTrigger value="approved">Approved</TabsTrigger>
          <TabsTrigger value="today">Today's Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pending Approvals</CardTitle>
              <CardDescription>Review and approve attendance records</CardDescription>
            </CardHeader>
            <CardContent>
              {pendingRecords.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No pending approvals
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Check In</TableHead>
                      <TableHead>Check Out</TableHead>
                      <TableHead>Hours</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingRecords.map((record) => (
                      <TableRow key={record.id}>
                        <TableCell>{record.employeeName}</TableCell>
                        <TableCell>{formatDate(record.checkIn)}</TableCell>
                        <TableCell>{formatTime(record.checkIn)}</TableCell>
                        <TableCell>
                          {record.checkOut ? formatTime(record.checkOut) : '-'}
                        </TableCell>
                        <TableCell>
                          {record.hoursWorked ? `${record.hoursWorked.toFixed(1)} hrs` : '-'}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleViewDetails(record)}
                            >
                              Details
                            </Button>
                            <Button
                              variant="default"
                              size="sm"
                              onClick={() => handleApprove(record.id)}
                            >
                              <Check className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => handleReject(record.id)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="approved" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Approved Records</CardTitle>
              <CardDescription>Previously approved attendance records</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Check In</TableHead>
                    <TableHead>Check Out</TableHead>
                    <TableHead>Hours</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {approvedRecords.slice(0, 20).map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>{record.employeeName}</TableCell>
                      <TableCell>{formatDate(record.checkIn)}</TableCell>
                      <TableCell>{formatTime(record.checkIn)}</TableCell>
                      <TableCell>
                        {record.checkOut ? formatTime(record.checkOut) : '-'}
                      </TableCell>
                      <TableCell>
                        {record.hoursWorked ? `${record.hoursWorked.toFixed(1)} hrs` : '-'}
                      </TableCell>
                      <TableCell>
                        <Badge variant="default">Approved</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="today" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Today's Activity</CardTitle>
              <CardDescription>Current attendance status</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Check In</TableHead>
                    <TableHead>Check Out</TableHead>
                    <TableHead>Hours</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {todayRecords.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>{record.employeeName}</TableCell>
                      <TableCell>{formatTime(record.checkIn)}</TableCell>
                      <TableCell>
                        {record.checkOut ? formatTime(record.checkOut) : '-'}
                      </TableCell>
                      <TableCell>
                        {record.hoursWorked ? `${record.hoursWorked.toFixed(1)} hrs` : '-'}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            record.status === 'checked-in'
                              ? 'secondary'
                              : record.status === 'checked-out'
                              ? 'default'
                              : 'outline'
                          }
                        >
                          {record.status === 'checked-in' ? 'Active' : record.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Attendance Record Details</DialogTitle>
            <DialogDescription>Review location and timing information</DialogDescription>
          </DialogHeader>
          {selectedRecord && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Employee</p>
                  <p className="text-sm">{selectedRecord.employeeName}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Date</p>
                  <p className="text-sm">{formatDate(selectedRecord.checkIn)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Check In Time</p>
                  <p className="text-sm">{formatTime(selectedRecord.checkIn)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Check Out Time</p>
                  <p className="text-sm">
                    {selectedRecord.checkOut ? formatTime(selectedRecord.checkOut) : 'N/A'}
                  </p>
                </div>
                <div className="col-span-2">
                  <p className="text-sm text-muted-foreground">Total Hours</p>
                  <p className="text-sm">
                    {selectedRecord.hoursWorked ? `${selectedRecord.hoursWorked.toFixed(2)} hours` : 'N/A'}
                  </p>
                </div>
              </div>

              <div className="border-t pt-4">
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <p className="text-sm">Check In Location</p>
                    </div>
                    <p className="text-xs text-muted-foreground pl-6">
                      {selectedRecord.checkInLocation.address}
                    </p>
                  </div>
                  {selectedRecord.checkOutLocation && (
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <p className="text-sm">Check Out Location</p>
                      </div>
                      <p className="text-xs text-muted-foreground pl-6">
                        {selectedRecord.checkOutLocation.address}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDetailsDialog(false)}>
              Close
            </Button>
            {selectedRecord && selectedRecord.status === 'pending-approval' && (
              <>
                <Button
                  variant="destructive"
                  onClick={() => handleReject(selectedRecord.id)}
                >
                  Reject
                </Button>
                <Button onClick={() => handleApprove(selectedRecord.id)}>
                  Approve
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
