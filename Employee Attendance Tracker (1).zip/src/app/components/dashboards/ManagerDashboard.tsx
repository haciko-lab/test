import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../ui/dialog';
import { Users, Clock, CheckCircle, XCircle, Download, Calendar } from 'lucide-react';
import { User, AttendanceRecord, LeaveRecord, LeaveBalance } from '../../types';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';

interface ManagerDashboardProps {
  user: User;
  allUsers: User[];
  allAttendanceRecords: AttendanceRecord[];
  allLeaveRecords: LeaveRecord[];
  allLeaveBalances: LeaveBalance[];
}

export function ManagerDashboard({ 
  user, 
  allUsers, 
  allAttendanceRecords, 
  allLeaveRecords,
  allLeaveBalances 
}: ManagerDashboardProps) {
  const { t } = useTranslation();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showUserDialog, setShowUserDialog] = useState(false);

  const activeEmployees = allUsers.filter(u => !u.isTerminated && u.role !== 'admin');
  const pendingApprovals = allAttendanceRecords.filter(r => !r.isApproved).length;
  const pendingLeaves = allLeaveRecords.filter(r => r.status === 'pending').length;

  const totalHours = allAttendanceRecords
    .filter(r => {
      const recordDate = new Date(r.date);
      const now = new Date();
      return recordDate.getMonth() === now.getMonth();
    })
    .reduce((sum, r) => sum + (r.totalHours || 0), 0);

  const handleApproveAttendance = (recordId: string) => {
    toast.success('Attendance approved');
  };

  const handleRejectAttendance = (recordId: string) => {
    toast.success('Attendance rejected');
  };

  const handleApproveLeave = (leaveId: string) => {
    toast.success('Leave request approved');
  };

  const handleRejectLeave = (leaveId: string) => {
    toast.success('Leave request rejected');
  };

  const handleExportToExcel = () => {
    const exportData = allUsers
      .filter(u => !u.isTerminated)
      .map(user => {
        const userRecords = allAttendanceRecords.filter(r => r.userId === user.id);
        const totalHours = userRecords.reduce((sum, r) => sum + (r.totalHours || 0), 0);
        const overtime = userRecords.reduce((sum, r) => sum + (r.overtimeHours || 0), 0);
        const balance = allLeaveBalances.find(b => b.userId === user.id);

        return {
          'Employee Name': user.fullName,
          'Department': user.department,
          'Employment Start': user.employmentStartDate,
          'Total Hours (Month)': totalHours.toFixed(1),
          'Overtime Hours': overtime.toFixed(1),
          'Annual Leave Remaining': balance?.annualLeaveRemaining || 0,
          'Leave Renewal Date': balance?.renewalDate || '',
        };
      });

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Employee Data');
    XLSX.writeFile(wb, 'employee-attendance-report.xlsx');
    toast.success('Report exported successfully');
  };

  const viewEmployeeDetails = (userId: string) => {
    const employee = allUsers.find(u => u.id === userId);
    if (employee) {
      setSelectedUser(employee);
      setShowUserDialog(true);
    }
  };

  const calculateAge = (dateOfBirth: string) => {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  return (
    <div className="max-w-7xl mx-auto p-4 space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Users className="h-4 w-4" />
              Active Employees
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">{activeEmployees.length}</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Total Hours
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">{totalHours.toFixed(0)}</div>
            <p className="text-xs text-gray-600">This month</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              Pending Approvals
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">{pendingApprovals}</div>
            <p className="text-xs text-gray-600">Attendance records</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Leave Requests
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">{pendingLeaves}</div>
            <p className="text-xs text-gray-600">Pending approval</p>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end">
        <Button onClick={handleExportToExcel} className="gap-2">
          <Download className="h-4 w-4" />
          {t('export')}
        </Button>
      </div>

      <Tabs defaultValue="team" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="team">Team Overview</TabsTrigger>
          <TabsTrigger value="attendance">Attendance Approvals</TabsTrigger>
          <TabsTrigger value="leaves">Leave Approvals</TabsTrigger>
        </TabsList>

        <TabsContent value="team">
          <Card>
            <CardHeader>
              <CardTitle>Team Members</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Hours (Month)</TableHead>
                    <TableHead>Overtime</TableHead>
                    <TableHead>Leave Balance</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activeEmployees.map(emp => {
                    const empRecords = allAttendanceRecords.filter(r => r.userId === emp.id);
                    const monthRecords = empRecords.filter(r => {
                      const d = new Date(r.date);
                      const now = new Date();
                      return d.getMonth() === now.getMonth();
                    });
                    const hours = monthRecords.reduce((s, r) => s + (r.totalHours || 0), 0);
                    const overtime = monthRecords.reduce((s, r) => s + (r.overtimeHours || 0), 0);
                    const balance = allLeaveBalances.find(b => b.userId === emp.id);

                    return (
                      <TableRow key={emp.id}>
                        <TableCell>{emp.fullName}</TableCell>
                        <TableCell>{emp.department}</TableCell>
                        <TableCell>{hours.toFixed(1)}h</TableCell>
                        <TableCell>
                          {overtime > 0 && (
                            <Badge variant="secondary">{overtime.toFixed(1)}h</Badge>
                          )}
                        </TableCell>
                        <TableCell>{balance?.annualLeaveRemaining || 0} days</TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => viewEmployeeDetails(emp.id)}
                          >
                            View Profile
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attendance">
          <Card>
            <CardHeader>
              <CardTitle>Pending Attendance Approvals</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Check In</TableHead>
                    <TableHead>Check Out</TableHead>
                    <TableHead>Hours</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {allAttendanceRecords.filter(r => !r.isApproved).map(record => {
                    const emp = allUsers.find(u => u.id === record.userId);
                    return (
                      <TableRow key={record.id}>
                        <TableCell>{emp?.fullName}</TableCell>
                        <TableCell>{record.date}</TableCell>
                        <TableCell>{record.checkInTime}</TableCell>
                        <TableCell>{record.checkOutTime}</TableCell>
                        <TableCell>{record.totalHours?.toFixed(1)}h</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="default"
                              onClick={() => handleApproveAttendance(record.id)}
                            >
                              <CheckCircle className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleRejectAttendance(record.id)}
                            >
                              <XCircle className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leaves">
          <Card>
            <CardHeader>
              <CardTitle>Pending Leave Requests</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {allLeaveRecords.filter(r => r.status === 'pending').map(leave => {
                  const emp = allUsers.find(u => u.id === leave.userId);
                  return (
                    <div key={leave.id} className="p-4 border rounded-lg">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="">{emp?.fullName}</p>
                          <p className="text-sm text-gray-600">{t(leave.leaveType + 'Leave')}</p>
                        </div>
                        <Badge>{leave.days} {t('days')}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">
                        {leave.startDate} to {leave.endDate}
                      </p>
                      <p className="text-sm mb-3">Reason: {leave.reason}</p>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleApproveLeave(leave.id)}
                          className="flex-1"
                        >
                          {t('approve')}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleRejectLeave(leave.id)}
                          className="flex-1"
                        >
                          {t('reject')}
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Employee Details Dialog */}
      <Dialog open={showUserDialog} onOpenChange={setShowUserDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Employee Profile</DialogTitle>
            <DialogDescription>Detailed information</DialogDescription>
          </DialogHeader>
          {selectedUser && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Full Name</p>
                  <p className="">{selectedUser.fullName}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Age</p>
                  <p className="">{calculateAge(selectedUser.dateOfBirth)} years</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Department</p>
                  <p className="">{selectedUser.department}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Employment Start</p>
                  <p className="">{selectedUser.employmentStartDate}</p>
                </div>
              </div>

              {(() => {
                const balance = allLeaveBalances.find(b => b.userId === selectedUser.id);
                return balance ? (
                  <div className="border-t pt-4">
                    <p className="text-sm mb-2">Leave Information</p>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 bg-blue-50 rounded">
                        <p className="text-xs text-gray-600">Annual Leave</p>
                        <p className="text-lg">{balance.annualLeaveRemaining}/{balance.annualLeaveTotal}</p>
                      </div>
                      <div className="p-3 bg-gray-50 rounded">
                        <p className="text-xs text-gray-600">Renewal Date</p>
                        <p className="text-sm">{balance.renewalDate}</p>
                      </div>
                    </div>
                  </div>
                ) : null;
              })()}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUserDialog(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
