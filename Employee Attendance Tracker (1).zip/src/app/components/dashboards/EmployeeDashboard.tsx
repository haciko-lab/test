import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Calendar } from '../ui/calendar';
import { Clock, MapPin, Calendar as CalendarIcon, TrendingUp, TrendingDown, CheckCircle } from 'lucide-react';
import { User, AttendanceRecord, LeaveRecord, LeaveBalance } from '../../types';
import { toast } from 'sonner';

interface EmployeeDashboardProps {
  user: User;
  attendanceRecords: AttendanceRecord[];
  leaveRecords: LeaveRecord[];
  leaveBalance: LeaveBalance;
}

export function EmployeeDashboard({ user, attendanceRecords, leaveRecords, leaveBalance }: EmployeeDashboardProps) {
  const { t } = useTranslation();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [isCheckedIn, setIsCheckedIn] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<string>('');

  const todayRecord = attendanceRecords.find(r => r.date === new Date().toISOString().split('T')[0]);
  const thisMonthRecords = attendanceRecords.filter(r => {
    const recordDate = new Date(r.date);
    const now = new Date();
    return recordDate.getMonth() === now.getMonth() && recordDate.getFullYear() === now.getFullYear();
  });

  const totalHoursThisMonth = thisMonthRecords.reduce((sum, r) => sum + (r.totalHours || 0), 0);
  const overtimeThisMonth = thisMonthRecords.reduce((sum, r) => sum + (r.overtimeHours || 0), 0);
  const underworkThisMonth = thisMonthRecords.reduce((sum, r) => sum + (r.underworkHours || 0), 0);

  const handleCheckIn = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation(`${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`);
          setIsCheckedIn(true);
          toast.success(t('checkIn') + ' successful!');
        },
        () => {
          setCurrentLocation('Office Location (Mock)');
          setIsCheckedIn(true);
          toast.success(t('checkIn') + ' successful with mock location');
        }
      );
    } else {
      setCurrentLocation('Office Location (Mock)');
      setIsCheckedIn(true);
      toast.success(t('checkIn') + ' successful');
    }
  };

  const handleCheckOut = () => {
    setIsCheckedIn(false);
    toast.success(t('checkOut') + ' successful!');
  };

  const getLeaveTypeColor = (type: string) => {
    switch (type) {
      case 'annual': return 'bg-blue-100 text-blue-800';
      case 'sick': return 'bg-red-100 text-red-800';
      case 'maternity': return 'bg-purple-100 text-purple-800';
      case 'special': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const leaveDates = leaveRecords
    .filter(r => r.status === 'approved')
    .flatMap(r => {
      const dates = [];
      const start = new Date(r.startDate);
      const end = new Date(r.endDate);
      for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
        dates.push(new Date(d).toISOString().split('T')[0]);
      }
      return dates;
    });

  return (
    <div className="max-w-7xl mx-auto p-4 space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Clock className="h-4 w-4 text-blue-600" />
              {t('thisMonth')} {t('hours')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">{totalHoursThisMonth.toFixed(1)}</div>
            <p className="text-xs text-blue-700 mt-1">{thisMonthRecords.length} {t('days')} worked</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-green-600" />
              Overtime
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">{overtimeThisMonth.toFixed(1)}h</div>
            <p className="text-xs text-green-700 mt-1">Additional hours</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingDown className="h-4 w-4 text-orange-600" />
              Underwork
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">{underworkThisMonth.toFixed(1)}h</div>
            <p className="text-xs text-orange-700 mt-1">Missing hours</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <CalendarIcon className="h-4 w-4 text-purple-600" />
              {t('annualLeave')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">{leaveBalance.annualLeaveRemaining}</div>
            <p className="text-xs text-purple-700 mt-1">of {leaveBalance.annualLeaveTotal} {t('days')}</p>
          </CardContent>
        </Card>
      </div>

      {/* Check In/Out Card */}
      <Card>
        <CardHeader>
          <CardTitle>{t('attendance')} Check</CardTitle>
          <CardDescription>Use GPS to mark your attendance</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {currentLocation && (
            <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
              <MapPin className="h-5 w-5 text-gray-600 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm">Current Location</p>
                <p className="text-xs text-gray-600">{currentLocation}</p>
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <Button
              size="lg"
              className="h-14"
              onClick={handleCheckIn}
              disabled={isCheckedIn}
            >
              <CheckCircle className="h-5 w-5 mr-2" />
              {t('checkIn')}
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="h-14"
              onClick={handleCheckOut}
              disabled={!isCheckedIn}
            >
              <Clock className="h-5 w-5 mr-2" />
              {t('checkOut')}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="attendance" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="leaves">Leaves</TabsTrigger>
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
        </TabsList>

        <TabsContent value="attendance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Attendance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {attendanceRecords.slice(0, 10).map(record => (
                  <div key={record.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <p className="text-sm">{record.date}</p>
                      <p className="text-xs text-gray-600">
                        {record.checkInTime} - {record.checkOutTime}
                      </p>
                    </div>
                    <div className="text-right space-y-1">
                      <p className="text-sm">{record.totalHours?.toFixed(1)}h</p>
                      <Badge variant={record.isApproved ? 'default' : 'secondary'}>
                        {record.isApproved ? 'Approved' : 'Pending'}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leaves" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Leave Balance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <p className="text-xs text-blue-700">Annual Leave</p>
                  <p className="text-2xl">{leaveBalance.annualLeaveRemaining}</p>
                  <p className="text-xs text-gray-600">of {leaveBalance.annualLeaveTotal} remaining</p>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-700">Renewal Date</p>
                  <p className="text-sm">{leaveBalance.renewalDate}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Leave History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {leaveRecords.map(leave => (
                  <div key={leave.id} className="p-4 border rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <Badge className={getLeaveTypeColor(leave.leaveType)}>
                        {t(leave.leaveType + 'Leave')}
                      </Badge>
                      <Badge variant={
                        leave.status === 'approved' ? 'default' :
                        leave.status === 'rejected' ? 'destructive' : 'secondary'
                      }>
                        {leave.status}
                      </Badge>
                    </div>
                    <p className="text-sm">{leave.startDate} to {leave.endDate}</p>
                    <p className="text-xs text-gray-600">{leave.days} {t('days')}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar">
          <Card>
            <CardHeader>
              <CardTitle>Leave Calendar</CardTitle>
              <CardDescription>View your approved leaves on calendar</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border"
                modifiers={{
                  leave: (date) => leaveDates.includes(date.toISOString().split('T')[0])
                }}
                modifiersClassNames={{
                  leave: 'bg-purple-200 text-purple-900'
                }}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
