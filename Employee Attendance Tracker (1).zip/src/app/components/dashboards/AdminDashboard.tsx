import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Users, Clock, TrendingUp, AlertCircle, UserPlus, Edit, UserX } from 'lucide-react';
import { User, AttendanceRecord, LeaveRecord, LeaveBalance } from '../../types';
import { toast } from 'sonner';

interface AdminDashboardProps {
  allUsers: User[];
  allAttendanceRecords: AttendanceRecord[];
  allLeaveRecords: LeaveRecord[];
  allLeaveBalances: LeaveBalance[];
}

export function AdminDashboard({
  allUsers,
  allAttendanceRecords,
  allLeaveRecords,
  allLeaveBalances
}: AdminDashboardProps) {
  const { t } = useTranslation();
  const [showAddUserDialog, setShowAddUserDialog] = useState(false);
  const [showEditUserDialog, setShowEditUserDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [newUser, setNewUser] = useState({
    fullName: '',
    dateOfBirth: '',
    employmentStartDate: '',
    role: 'employee' as const,
    department: '',
  });

  const activeEmployees = allUsers.filter(u => !u.isTerminated);
  const terminatedEmployees = allUsers.filter(u => u.isTerminated);
  const totalHours = allAttendanceRecords.reduce((s, r) => s + (r.totalHours || 0), 0);
  const totalOvertime = allAttendanceRecords.reduce((s, r) => s + (r.overtimeHours || 0), 0);
  const pendingApprovals = allAttendanceRecords.filter(r => !r.isApproved).length;

  const handleAddEmployee = () => {
    if (!newUser.fullName || !newUser.dateOfBirth || !newUser.employmentStartDate || !newUser.department) {
      toast.error('Please fill all fields');
      return;
    }
    toast.success('Employee added successfully');
    setShowAddUserDialog(false);
    setNewUser({
      fullName: '',
      dateOfBirth: '',
      employmentStartDate: '',
      role: 'employee',
      department: '',
    });
  };

  const handleTerminateEmployee = (userId: string) => {
    toast.success('Employee marked as terminated');
  };

  const handleEditEmployee = (userId: string) => {
    const user = allUsers.find(u => u.id === userId);
    if (user) {
      setSelectedUser(user);
      setShowEditUserDialog(true);
    }
  };

  const calculateAge = (dateOfBirth: string) => {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  return (
    <div className="max-w-7xl mx-auto p-4 space-y-6">
      {/* System Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Users className="h-4 w-4" />
              Total Employees
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">{allUsers.length}</div>
            <p className="text-xs text-gray-600">{activeEmployees.length} active</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Total Hours
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">{totalHours.toFixed(0)}</div>
            <p className="text-xs text-gray-600">All time</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Overtime Hours
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">{totalOvertime.toFixed(0)}</div>
            <p className="text-xs text-gray-600">System-wide</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <AlertCircle className="h-4 w-4" />
              Pending Items
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">{pendingApprovals}</div>
            <p className="text-xs text-gray-600">Need approval</p>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end">
        <Button onClick={() => setShowAddUserDialog(true)} className="gap-2">
          <UserPlus className="h-4 w-4" />
          Add New Employee
        </Button>
      </div>

      <Tabs defaultValue="active" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="active">Active Employees</TabsTrigger>
          <TabsTrigger value="terminated">Terminated</TabsTrigger>
          <TabsTrigger value="statistics">Statistics</TabsTrigger>
        </TabsList>

        <TabsContent value="active">
          <Card>
            <CardHeader>
              <CardTitle>Active Employees</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Age</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Leave Balance</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activeEmployees.map(emp => {
                    const balance = allLeaveBalances.find(b => b.userId === emp.id);
                    return (
                      <TableRow key={emp.id}>
                        <TableCell>{emp.fullName}</TableCell>
                        <TableCell>{calculateAge(emp.dateOfBirth)}</TableCell>
                        <TableCell>{emp.department}</TableCell>
                        <TableCell>{emp.employmentStartDate}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{t(emp.role)}</Badge>
                        </TableCell>
                        <TableCell>
                          {balance ? `${balance.annualLeaveRemaining}/${balance.annualLeaveTotal}` : '-'}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditEmployee(emp.id)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleTerminateEmployee(emp.id)}
                            >
                              <UserX className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="terminated">
          <Card>
            <CardHeader>
              <CardTitle>Terminated Employees</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Employment Period</TableHead>
                    <TableHead>Terminated Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {terminatedEmployees.map(emp => (
                    <TableRow key={emp.id}>
                      <TableCell>{emp.fullName}</TableCell>
                      <TableCell>{emp.department}</TableCell>
                      <TableCell>{emp.employmentStartDate}</TableCell>
                      <TableCell>{emp.terminatedDate || '-'}</TableCell>
                    </TableRow>
                  ))}
                  {terminatedEmployees.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-gray-500">
                        No terminated employees
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="statistics">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Department Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Object.entries(
                    activeEmployees.reduce((acc, emp) => {
                      acc[emp.department] = (acc[emp.department] || 0) + 1;
                      return acc;
                    }, {} as Record<string, number>)
                  ).map(([dept, count]) => (
                    <div key={dept} className="flex items-center justify-between p-3 border rounded">
                      <span>{dept}</span>
                      <Badge>{count} employees</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>System Overview</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 border rounded">
                  <p className="text-sm text-gray-600">Total Attendance Records</p>
                  <p className="text-2xl">{allAttendanceRecords.length}</p>
                </div>
                <div className="p-3 border rounded">
                  <p className="text-sm text-gray-600">Total Leave Requests</p>
                  <p className="text-2xl">{allLeaveRecords.length}</p>
                </div>
                <div className="p-3 border rounded">
                  <p className="text-sm text-gray-600">Average Hours per Employee</p>
                  <p className="text-2xl">
                    {(totalHours / activeEmployees.length).toFixed(1)}h
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Add Employee Dialog */}
      <Dialog open={showAddUserDialog} onOpenChange={setShowAddUserDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Employee</DialogTitle>
            <DialogDescription>Enter employee details</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                value={newUser.fullName}
                onChange={(e) => setNewUser({ ...newUser, fullName: e.target.value })}
                placeholder="John Doe"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dob">Date of Birth</Label>
              <Input
                id="dob"
                type="date"
                value={newUser.dateOfBirth}
                onChange={(e) => setNewUser({ ...newUser, dateOfBirth: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="startDate">Employment Start Date</Label>
              <Input
                id="startDate"
                type="date"
                value={newUser.employmentStartDate}
                onChange={(e) => setNewUser({ ...newUser, employmentStartDate: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="department">Department</Label>
              <Input
                id="department"
                value={newUser.department}
                onChange={(e) => setNewUser({ ...newUser, department: e.target.value })}
                placeholder="Engineering"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="role">Role</Label>
              <Select value={newUser.role} onValueChange={(v: any) => setNewUser({ ...newUser, role: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="employee">{t('employee')}</SelectItem>
                  <SelectItem value="manager">{t('manager')}</SelectItem>
                  <SelectItem value="admin">{t('admin')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddUserDialog(false)}>
              {t('cancel')}
            </Button>
            <Button onClick={handleAddEmployee}>{t('save')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Employee Dialog */}
      <Dialog open={showEditUserDialog} onOpenChange={setShowEditUserDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Employee</DialogTitle>
            <DialogDescription>Update employee information</DialogDescription>
          </DialogHeader>
          {selectedUser && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input value={selectedUser.fullName} readOnly />
              </div>
              <div className="space-y-2">
                <Label>Department</Label>
                <Input defaultValue={selectedUser.department} />
              </div>
              <div className="space-y-2">
                <Label>Role</Label>
                <Select defaultValue={selectedUser.role}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="employee">{t('employee')}</SelectItem>
                    <SelectItem value="manager">{t('manager')}</SelectItem>
                    <SelectItem value="admin">{t('admin')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditUserDialog(false)}>
              {t('cancel')}
            </Button>
            <Button onClick={() => {
              toast.success('Employee updated');
              setShowEditUserDialog(false);
            }}>
              {t('save')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
