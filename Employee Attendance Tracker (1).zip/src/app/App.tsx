import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import './lib/i18n';
import { Toaster } from './components/ui/sonner';
import { EmployeeDashboard } from './components/dashboards/EmployeeDashboard';
import { ManagerDashboard } from './components/dashboards/ManagerDashboard';
import { AdminDashboard } from './components/dashboards/AdminDashboard';
import { NavigationBar } from './components/layout/NavigationBar';
import { LoginScreen } from './components/auth/LoginScreen';
import { Role, User, AttendanceRecord, LeaveRecord, LeaveBalance } from './types';
import { generateMockData } from './lib/mockData';

export default function App() {
  const { i18n } = useTranslation();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentRole, setCurrentRole] = useState<Role | null>(null);
  const [mockData, setMockData] = useState(generateMockData());

  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    const savedRole = localStorage.getItem('currentRole');
    if (savedUser && savedRole) {
      setCurrentUser(JSON.parse(savedUser));
      setCurrentRole(savedRole as Role);
    }
  }, []);

  const handleLogin = (user: User, role: Role) => {
    setCurrentUser(user);
    setCurrentRole(role);
    localStorage.setItem('currentUser', JSON.stringify(user));
    localStorage.setItem('currentRole', role);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentRole(null);
    localStorage.removeItem('currentUser');
    localStorage.removeItem('currentRole');
  };

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    localStorage.setItem('language', lng);
  };

  if (!currentUser || !currentRole) {
    return (
      <>
        <LoginScreen onLogin={handleLogin} users={mockData.users} />
        <Toaster />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationBar
        user={currentUser}
        role={currentRole}
        onLogout={handleLogout}
        onLanguageChange={changeLanguage}
        currentLanguage={i18n.language}
      />

      <main className="pb-20 md:pb-8">
        {currentRole === 'employee' && (
          <EmployeeDashboard
            user={currentUser}
            attendanceRecords={mockData.attendanceRecords.filter(r => r.userId === currentUser.id)}
            leaveRecords={mockData.leaveRecords.filter(r => r.userId === currentUser.id)}
            leaveBalance={mockData.leaveBalances.find(b => b.userId === currentUser.id)!}
          />
        )}

        {currentRole === 'manager' && (
          <ManagerDashboard
            user={currentUser}
            allUsers={mockData.users}
            allAttendanceRecords={mockData.attendanceRecords}
            allLeaveRecords={mockData.leaveRecords}
            allLeaveBalances={mockData.leaveBalances}
          />
        )}

        {currentRole === 'admin' && (
          <AdminDashboard
            allUsers={mockData.users}
            allAttendanceRecords={mockData.attendanceRecords}
            allLeaveRecords={mockData.leaveRecords}
            allLeaveBalances={mockData.leaveBalances}
          />
        )}
      </main>

      <Toaster />
    </div>
  );
}
